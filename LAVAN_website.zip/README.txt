LAVAN website package
1) Keep index.html, style.css, script.js together.
2) Replace lavan_model_1.jpg through lavan_model_7.jpg with the real LAVAN images.
3) Upload the whole folder/ZIP to a static hosting service such as Tiiny Host.
4) The placeholder images in this package are only temporary.
