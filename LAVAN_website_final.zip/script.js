function openImage(src){const m=document.getElementById("modal");document.getElementById("modalImg").src=src;m.classList.add("show");document.body.style.overflow="hidden"}
function closeImage(e){if(e){e.stopPropagation();if(e.target.id!=="modal" && !e.target.classList.contains("modal-close"))return;}const m=document.getElementById("modal");m.classList.remove("show");document.body.style.overflow=""}
function toggleMenu(){document.querySelector(".header nav").classList.toggle("mobile-open")}
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeImage();});
document.querySelectorAll(".header nav a").forEach(a=>a.addEventListener("click",()=>document.querySelector(".header nav").classList.remove("mobile-open")));